/*
https://www.geeksforgeeks.org/count-subarrays-with-consecutive-elements-differing-by-1/
Given an array arr[] of N integers. The task is to count the total number of subarrays of the given array such that the difference between the consecutive elements in the subarrays is one. That is, for any index i in the subarrays, arr[i+1] – arr[i] = 1.
Note: Do not consider subarrays with a single element.
Examples:


Input : arr[] = {1, 2, 3}
Output : 3
The subarrays are {1, 2}. {2, 3} and {1, 2, 3}

Input : arr[] = {1, 2, 3, 5, 6, 7}
Output : 6
*/

function CountSubArr(arr) {
  let result = 0;
  for (let start=0; start<arr.length-1; start++) {
    let subres = 0;
    let end = start+1;
    for (; end<arr.length; end++) {
      if (arr[end]-arr[end-1] === 1) {
        subres++;
      } else {
        break;
      }
    }
    result += subres*(subres+1)/2;
    start = end - 1;
  }
  return result;
}

// let arr1 = [1,2,3];
// let arr2 = [1,2,3,5,6,7,8];
// let arr3 = [1]
// console.log(CountSubArr(arr1))
// console.log(CountSubArr(arr2))

//Another solution online
/*
// Function to count Subarrays with
    // Consecutive elements differing by 1
    function subarrayCount(arr , n) {
        // Variable to store count of subarrays
        // whose consecutive elements differ by 1
        var result = 0;

        // Take two pointers for maintaining a
        // window of consecutive elements
        var fast = 0, slow = 0;

        // Traverse the array
        for (i = 1; i < n; i++) {

            // If elements differ by 1
            // increment only the fast pointer
            if (arr[i] - arr[i - 1] == 1) {
                fast++;
            } else {

                // Calculate length of subarray
                var len = fast - slow + 1;

                // Calculate total subarrays except
                // Subarrays with single element
                result += len * (len - 1) / 2;

                // Update fast and slow
                fast = i;
                slow = i;
            }
        }

        // For last iteration. That is if array is
        // traversed and fast > slow
        if (fast != slow) {
            var len = fast - slow + 1;
            result += len * (len - 1) / 2;
        }

        return result;
    }

    // Driver Code


        var arr = [ 1, 2, 3, 5, 6, 7 ];
        var n = arr.length;

        document.write(subarrayCount(arr, n));
*/