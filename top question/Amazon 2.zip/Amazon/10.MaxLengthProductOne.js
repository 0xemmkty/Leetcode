/*
Given an array of only 1 and -1, find a subarray of maximum length such that the product of all the elements in the subarray is 1
 */
function MaxLengthProductOne(array){
  let start, end; //track the first -1 and last -1
  let count = 0; //track the frequency of -1
  for(let i=0; i<array.length; i++){
    if(array[i] === -1) {
      if(start===undefined){
        start = i;
      }
      end = i
      count++;
    }
  }
  if(count%2===0) {
    return array.length;
  }
  return Math.max(array.length-start-1, end);
}

// let arr1 = [1,-1,-1,1,1,1,1,-1,-1,1];
// let arr2 = [1,-1,-1,1,1,1,1,-1,-1,1,-1,-1,1,-1];
// let arr3 = [-1]
// console.log(MaxLengthProductOne(arr1),MaxLengthProductOne(arr2),MaxLengthProductOne(arr3));