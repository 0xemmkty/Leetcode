/*
Given an array of binary digits, 0 and 1, sort the array so that all zeros are at one end and all ones are at the other. Which end does not matter. To sort the array, swap any two adjacent elements. Determine the minimum number of swaps to sort the array.

Example
arr = [0, 1, 0, 1]
With 1 move, switching elements 1 and 2 yields [0, 0, 1, 1], a sorted array

Function Description
Complete the function minMoves

minMoves has the following parameter(s):
int arr[n]: an array of binary digits

Returns
int: the minimum number of moves necessarry

Constraints

1 <= n <= 10^5
arr[i] is in the set {0, 1}
Another Example
arr = [1, 1, 1, 1, 0, 0, 0 0]
We return 0 because we do not need to swap any elements
*/

function GroupDigit(arr) {
  let swap01 = 0;
  let count1 = 0;
  for(let i=0; i<arr.length; i++) {
    if(arr[i] === 0) {
      swap01 += count1;
    } else {
      count1 = count1+1;
    }
  }

  let swap10 = 0;
  let count0 = 0;
  for(let i=0; i<arr.length; i++) {
    if(arr[i] === 1) {
      swap10 += count0;
    } else {
      count0 = count0+1;
    }
  }
  return Math.min(swap01, swap10);
}