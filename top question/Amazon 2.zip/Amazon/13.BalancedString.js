/*
Given a String S return the number of ways you could split the string into balanced strings. ? could be replaced with ( or ) or [ or ].

So for example let say S = [(?]]??[ split the string into [(?] and ]??[ .

1st way
so for the first string [(?] --> ? could be replaced with ) and it would make it [()]
so for the first string ]??[ --> First ? could be replaced with ] and it would make it ]]?[. Then replace the second ? with ] and it would make it []][ and then interchange ] and [ and would make it [][].
2nd way
so for the first string [(?] --> ? could be replaced with ) and it would make it [()]
so for the first string ]??** --> First ? could be replaced with ( and replace the second ? with ) and it would make it **[ then interchange ] and [ and would make it [()].
*/

function balancedString(s){
  let output = 0;
  function isBalanced(a,b,q){
    let total = Math.abs(a)+Math.abs(b);
    if(total<q){
      q = q - total;
      if(q%2===0){
        return true;
      }
    }
    return false;
  }
  let count={};
  for(let i=0;i<s.length;i++){
    if(count[s[i]]===undefined){
      count[s[i]]=1;
    }else{
      count[s[i]]++;
    }
  }
  let ta = count["("]-count[")"];
  let tb = count["["]-count["]"];
  let tq = count["?"];
  let a, b, q = 0;
  for(let i=0;i<s.length-1;i++){
    if(s[i]==='(') {
      a++;
    }else if(s[i]===")"){
      a--;
    }else if(s[i]==="["){
      b++;
    }else if(s[i]==="]"){
      b--;
    }else {
      q++;
    }
    if(i%2===0){
      if(isBalanced(a,b,q) && isBalanced(ta-a,tb-b,ta-q)) {
        output++;
      }
    }
  }
}
