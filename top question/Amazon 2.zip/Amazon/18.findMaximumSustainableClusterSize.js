/*
Give you a list servers. Their processing power is given as a array of integer, and boot power as a array of integer.
Write a function to return the max length of sub array which's power consumption is less than or equal to max power limit.
Formula to calculate the power consumption for a subArray is:
Max(bootPower[i...j]) + Sum(processPower[i....j]) * length of subArray.

Note: Single server is also a subArray, return 0 if no such subArray can be found.

Example:
let bootPower = [2,3,4,6,1,2];
let processPower = [1,3,5,6,4,2];
*/

var findMaximumSustainableClusterSize = function(processPower, bootPower, powerMax) {
  let start = 0, end = 0, n = processPower.length;
  let queue = [], ans = 0, sum = 0;
  while(end<n) {
    sum = sum+processPower[end];
    while(queue.length>0 && queue[queue.length-1][0]<=bootPower[end]) {
      queue.pop();
    }
    queue.push([bootPower[end], end]);

    while(start<=end && queue[0][0] + sum*(end-start+1)>powerMax) {
      if (queue[0][1] === start) {
        queue.shift();
      }
      sum = sum - processPower[start];
      start++;
    }
    ans = Math.max(ans, end-start+1);
    end++;
  }
  return ans;
}

// let bootPower = [8,8,10,9,12];
// let processPower = [4,1,4,5,3];
// let powerMax = 100;
// console.log(findMaximumSustainableClusterSize(processPower, bootPower, powerMax));