/*
https://gongybable.medium.com/amazon-oa-question-different-types-of-pages-y-tech-442d5ffb9a56
The Amazon Kindle Store is an online e-book store where readers can choose a book from a wide range of categories. It also provides the ability to bookmark pages the user wishes to return to later. A book is represented as a binary string having two types of pages:

‘0’: an ordinary page
‘1’: a bookmarked page

Find the number of ways to select 3 pages in ascending index order such that no two adjacent selected pages are of the same type.

Example 1:

book = '01001' The following sequences of pages match the criterion: [1, 2 ,3], that is, 01001 → 010. [1, 2 ,4], that is, 01001 → 010. [2, 3 ,5], that is, 01001 → 101. [2, 4 ,5], that is, 01001 → 101. The answer is 4.
*/

function NumberOfWays(pages) {
  //3 pages, consider the page in the middle: if 1, number of ways = number of 0s on the left * number of 1s on the right
  //keep track how many zeros are there in the left and right of a position i - this also gives info for the number of ones
  let n = pages.length;
  let lzeros= Array(n).fill(0), rzeros = Array(n).fill(0);
  for(let i=0; i<n; i++) {
    if(i!==0) {
      if(pages[i-1]==="0") {
        lzeros[i] = lzeros[i-1]+1;
      }else {
        lzeros[i] = lzeros[i-1];
      }
    }
    if(i!==n-1) {
      if(pages[n-i-1]==="0") {
        rzeros[n-i-2] = rzeros[n-i-1]+1;
      }else {
        rzeros[n-i-2] = rzeros[n-i-1];
      }
    }
  }
  console.log(lzeros, rzeros);
  let count = 0;
  for(let i=1; i<n-1; i++) {
    if(pages[i]==="0"){
      count += (i-lzeros[i])*(n-i-1-rzeros[i]);
    }else {
      count += lzeros[i]*rzeros[i];
    }
  }
  return count;
}

// let bk1 = '01001';
// let bk2 = '0110';
// console.log(NumberOfWays(bk1),NumberOfWays(bk2));

//Other methods online
/*
from collections import defaultdict

def solution(book_str):
    res = 0
    count_map = defaultdict(int)
    for page in book_str:
        count_map[page] += 1

    zeros = count_map['0']
    ones = count_map['1']

    # try the case 101
    starting_ones = 0
    ending_ones = ones
    for page in book_str:
        if page == '0':
            res += starting_ones * ending_ones
        else:
            ending_ones -= 1
            starting_ones += 1

    # try the case 010
    starting_zeros = 0
    ending_zeros = zeros
    for page in book_str:
        if page == '1':
            res += starting_zeros * ending_zeros
        else:
            ending_zeros -= 1
            starting_zeros += 1

    return res
*/

/*

def solution(book_str):
    res = 0
    count_map = defaultdict(int)
    for page in book_str:
        count_map[page] += 1

    zeros = count_map['0']
    ones = count_map['1']

    # starting counts for 0 and 1
    starting_count = {
        '0': 0,
        '1': 0
    }
    for page in book_str:
        if page == '0':
            starting_ones = starting_count['1']
            ending_ones = ones - starting_ones
            res += starting_ones * ending_ones
            starting_count['0'] += 1
        else:
            starting_zeros = starting_count['0']
            ending_zeros = zeros - starting_zeros
            res += starting_zeros * ending_zeros
            starting_count['1'] += 1

    return res
*/
