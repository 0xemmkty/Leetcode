/*
There are 3 rules for a valid string:

An empty string is valid
You can add same character to a valid string X, and create another valid string yXy
You can concatenate two valid strings X and Y, so XY will also be valid.
Ex: vv, xbbx, bbccdd, xyffyxdd are all valid.
*/

function ValidCoupon(coupon){
  let stack=[];
  for(let i=0; i<coupon.length; i++){
    if(stack.length===0 || coupon[i]!==stack[stack.length-1]){
      stack.push(coupon[i]);
    } else {
      stack.pop();
    }
  }
  if(stack.length === 0) {
    return true;
  }
  return false;
}

// let cp1 = "";
// let cp2 = "yaay";
// let cp3 = "xyffyxdd"
// let cp4 = "asssa"
// console.log(ValidCoupon(cp1),ValidCoupon(cp2),ValidCoupon(cp3),ValidCoupon(cp4));