/*
https://leetcode.com/problems/shortest-path-in-binary-matrix/
Given an n x n binary matrix grid, return the length of the shortest clear path in the matrix. If there is no clear path, return -1.

A clear path in a binary matrix is a path from the top-left cell (i.e., (0, 0)) to the bottom-right cell (i.e., (n - 1, n - 1)) such that:

All the visited cells of the path are 0.
All the adjacent cells of the path are 8-directionally connected (i.e., they are different and they share an edge or a corner).
The length of a clear path is the number of visited cells of this path.
*/
var shortestPathBinaryMatrix = function(grid) {
  let output = 0, n = grid.length;
  if(grid[0][0]===1 || grid[n-1][n-1]===1) {
      return -1;
  }
  if(n===1) {
      return 1;
  }
  let queue = [[0,0]];
  let dirs = [[1,1],[1,0],[0,1],[1,-1],[0,-1],[-1,0],[-1,-1],[-1,1]];
  let visited = Array.from({length:n}, ()=>Array(n).fill(false))
  while(queue.length>0) {
      const size = queue.length;
      output++;
      for(let i=0; i<size; i++) {
          let point = queue.shift();
          visited[point[0]][point[1]] = true;
          for(let dir of dirs) {
              let row = point[0]+dir[0];
              let col = point[1]+dir[1];
              if(row===n-1 && col===n-1) {
                  return output+1;
              }
              if(row>=0 && row<n && col>=0 && col<n && visited[row][col]===false && grid[row][col]===0) {
                  queue.push([row, col]);
                  visited[row][col] = true;
              }
          }
      }
  }
  return -1;
};