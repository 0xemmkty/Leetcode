/*
https://leetcode.com/discuss/interview-experience/1972148/amazon-oa-april-2022-served-buildings-number-of-ways-to-choose-3-pages
Find the number of served buildings

Given:

Head count for a list of buildings
Array of range for each router
Array of location of each router
If a router location is i and it's range is k then it will serve buildings at indices i-k to i+k inclusive.

A building is considered as served if the number of routers serving that building is greater than or equal to head count of that building.

Test case 1:
headCount: [2, 3, 3, 1, 5, 6]
routerLocation: [2, 4, 3]
routerRange: [2, 4, 1]

Number of routrers serving each building would be [2, 2, 3, 3, 3, 1] so buildings at indices. 0, 2 and 3 would be considered as served and hence the answer would be 3 (number of served buildings).
*/

var getServedBuildings = function(headCount, routerLoc, routerRange) {
  let count = Array(headCount.length).fill(0);
  for(let i=0; i<routerLocation.length; i++) {
    let loc = routerLocation[i]
    let start = Math.max(0, loc-routerRange[i]);
    let end = Math.min(headCount.length-1, loc+routerRange[i]);
    for(let j=start; j<=end; j++) {
      count[j]+=1;
    }
  }
  let served = 0;
  for(let i=0; i<headCount.length; i++) {
    if(headCount[i]<=count[i]){
      served ++;
    }
  }
  return served;
}

// let headCount=[2, 3, 3, 1, 5, 6]
// let routerLocation=[2, 4, 3]
// let routerRange=[2, 4, 1]
// console.log(getServedBuildings(headCount, routerLocation, routerRange));