/*
A binary string is monotone increasing if it consists of some number of 0's (possibly none), followed by some number of 1's (also possibly none).

You are given a binary string s. You can flip s[i] changing it from 0 to 1 or from 1 to 0.

Return the minimum number of flips to make s monotone increasing.

Example 1:

Input: s = "00110"
Output: 1
Explanation: We flip the last digit to get 00111.
Example 2:

Input: s = "010110"
Output: 2
Explanation: We flip to get 011111, or alternatively 000111.
Example 3:

Input: s = "00011000"
Output: 2
Explanation: We flip to get 00000000.
*/

var minFlipsMonoIncr = function(s) {
  let n = s.length;
  let dpzero = Array(n).fill(0);
  let dpone = Array(n).fill(0);
  for(let i=0; i<n; i++) {
    if(i===0) {
      if(s[0]==="0") {
        dpone[1] = 1;
      }else {
        dpzero[0] = 1;
      }
    } else {
      if(s[i]==="0") {
        dpzero[i] = dpzero[i-1];
        dpone[i] = Math.min(dpzero[i-1], dpone[i-1]) + 1;
      } else {
        dpzero[i] = dpzero[i-1]+1;
        dpone[i] = Math.min(dpzero[i-1], dpone[i-1]);
      }
    }
  }
  return Math.min(dpzero[n-1], dpone[n-1]);
};

// let s1 = "00110";
// let s2 = "010110";
// let s3 = "00011000";

// console.log(minFlipsMonoIncr(s1), minFlipsMonoIncr(s2), minFlipsMonoIncr(s3));