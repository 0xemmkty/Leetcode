/*
Given string s, calculate the maximum deviation of all substrings.
The maximum deviation is the difference between the maximum frequency of a character and the minimum frequency of a character.

For example, in abcaba, a has a frequency of 3; b has a frequency of 2; c has a frequency of 1. so a has the maximum frequency, which is 3, whereas c has a minimum frequency of 1. Therefore the deviation of this string is 3 - 1 = 2. And we also need to find all other deviations for each of the substrings for abacaba, the maximum among them is the answer.
*/

var MaxDeviSubstring = function(s) {
  let max = 0;
  for(let i=0; i<s.length-1; i++) {
    for(let j=i+max; j<s.length; j++) {
      let maxsub = findMaxDevi(s.slice(i,j+1));
      if (maxsub > max) {
        max = maxsub;
      }
    }
  }
  function findMaxDevi(subs) {
    let max = -Infinity;
    let count = {};
    for(let i=0; i<subs.length; i++) {
      let item = subs[i];
      if(count[item] === undefined) {
        count[item] = 1;
      } else {
        count[item] += 1;
      }
      if(count[item] > max) {
        max = count[item];
      }
    }
    let min = Object.values(count).sort((a,b)=>a-b)[0];
    return max-min;
  }
  return max;
}

// let s1 = 'abcaba';
// let s2 = 'abcabaaaa';
// let s3 = 'aaaaaa'
// console.log(MaxDeviSubstring(s1), MaxDeviSubstring(s2), MaxDeviSubstring(s3));