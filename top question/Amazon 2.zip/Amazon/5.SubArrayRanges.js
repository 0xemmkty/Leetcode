/*
You are given an integer array nums. The range of a subarray of nums is the difference between the largest and smallest element in the subarray.

Return the sum of all subarray ranges of nums.

A subarray is a contiguous non-empty sequence of elements within an array.
*/

var subArrayRanges = function(nums) {
  let sum = 0;

  for(let start=0; start<nums.length; start++) {
      let min = nums[start];
      let max = nums[start];
      for(let end=start+1; end<nums.length; end++) {
          if (nums[end]>max) {
              max = nums[end];
          }
          if (nums[end]<min) {
              min = nums[end];
          }
          sum += max-min;
      }
  }
  return sum;
};