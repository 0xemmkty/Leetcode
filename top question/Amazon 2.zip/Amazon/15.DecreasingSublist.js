/*
Count the number of decreasing sublists (can be one element) in a list
*/

var decreasingSublist = function(list) {
  let count = list.length;
  for(let start=0; start<list.length-1; start++) {
    let end = start+1;
    let subcount = 0;
    for(; end<list.length; end++) {
      if(list[end]<list[end-1]){
        subcount++;
      }else {
        break;
      }
    }
    count += (subcount+1)*subcount/2;
    start = end-1;
  }
  return count;
}

// let arr1=[4,3,5,4,3];
// let arr2=[4,4,3,5,3,4];
// console.log(decreasingSublist(arr1),decreasingSublist(arr2));

//other solutions online
/*
public class Main {
    public static void main(String[] args) {
        int[] array = new int[]{4, 3, 5, 4, 3};
        int[] arr2 = new int[]{4, 4, 3, 5, 3, 4};
        System.out.println(decreasingSubarray(array));
        System.out.println(decreasingSubarray(arr2));
    }
    private static int decreasingSubarray(int[] array){
        Stack<Integer> stack = new Stack<>();
        int count = 0;
        for(int i = 0; i < array.length; i++){
            if(!stack.isEmpty() && stack.peek() <= array[i]){
                stack.clear();
            }
            stack.push(array[i]);
            count += stack.size();
        }
        return count;
    }
}
*/