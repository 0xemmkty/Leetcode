/*
https://leetcode.com/problems/sequentially-ordinal-rank-tracker/
*/

var SORTracker = function() {
  this.minH = new MinHeap();
  this.maxH = new MaxHeap();
};

/**
* @param {string} name
* @param {number} score
* @return {void}
*/
SORTracker.prototype.add = function(name, score) {
  this.minH.push([name,score])
  let k = this.minH.pop();
  this.maxH.push(k);
};

/**
* @return {string}
*/
SORTracker.prototype.get = function() {
  let k = this.maxH.pop();
  this.minH.push(k);
  return k[0];
};

/**
* Your SORTracker object will be instantiated and called as such:
* var obj = new SORTracker()
* obj.add(name,score)
* var param_2 = obj.get()
*/

class MinHeap{
  constructor(){
      this.heap = []
  }
  push(val) {
      this.heap.push(val);
      this.shiftUp(this.heap.length-1);
  }
  more(i, j) {
      if (this.heap[i][1] === this.heap[j][1]) {
          return this.heap[i][0].localeCompare(this.heap[j][0]) === -1;
      }
      return this.heap[i][1]> this.heap[j][1];
  }
  swap(i, j) {
      let temp = this.heap[i];
      this.heap[i] = this.heap[j];
      this.heap[j] = temp;
  }
  shiftUp(ind){
      while(ind>0 && this.more(Math.floor((ind-1)/2),ind)) {
          this.swap(Math.floor((ind-1)/2), ind);
          ind = Math.floor((ind-1)/2);
      }
  }
  pop() {
      this.swap(0, this.heap.length-1);
      let top = this.heap.pop();
      this.shiftDown(0);
      return top;
  }
  shiftDown(ind){
      while(2*ind+1 <= this.heap.length-1) {
          let j = 2*ind+1;
          if(this.heap[j+1] && this.more(j,j+1)) {
              j+=1;
          }
          if(this.more(j, ind)) {
              break;
          }
          this.swap(ind,j);
          ind =j;
      }
  }
}

class MaxHeap{
  constructor() {
      this.heap = [];
  }
  push(val) {
      this.heap.push(val);
      this.shiftUp(this.heap.length-1);
  }
  more(i, j) {
      if (this.heap[i][1] === this.heap[j][1]) {
          return this.heap[i][0].localeCompare(this.heap[j][0]) === -1;
      }
      return this.heap[i][1]> this.heap[j][1];
  }
  swap(i,j) {
      let temp = this.heap[i];
      this.heap[i] = this.heap[j];
      this.heap[j] = temp;
  }
  shiftUp(ind) {
      while(ind>0 && this.more(ind, Math.floor((ind-1)/2))){
          this.swap(ind, Math.floor((ind-1)/2));
          ind = Math.floor((ind-1)/2);
      }
  }
  pop() {
      this.swap(0, this.heap.length-1);
      let top = this.heap.pop();
      this.shiftDown(0);
      return top;
  }
  shiftDown(ind) {
      while(ind*2+1<=this.heap.length-1) {
          let j=ind*2+1;
          if(this.heap[j+1] && this.more(j+1,j)){
              j=j+1;
          }
          if(this.more(ind,j)) {
              break;
          }
          this.swap(ind, j);
          ind = j;
      }
  }
}